var app = angular.module("myApp", [])


app.controller("RegisterController", function ($scope, $http,$window, $httpParamSerializerJQLike) {

    $scope.pageClass = 'register';
$scope.register = function(username, password, email) {
   console.log("inside login function");
$http({
    method: 'POST',
    url : 'https://api.mongolab.com/api/1/databases/ase_lab1/collections/users?apiKey=j1ttIfJ4D9Aol5Ru3bFCtLTAilPI2-v1',
    data: JSON.stringify({
                name: username,
                password: password,
                email: email
            }),
    contentType: "application/json"
}).success(function() {
    $scope.userName ="";
    $scope.password ="";
    $scope.email ="";
    
    $scope.msg ="User created successfully";
        })
}

$scope.login = function(username, password) {
   console.log("inside login function");
$http({
    method: 'GET',
    url : 'https://api.mongolab.com/api/1/databases/ase_lab1/collections/users?apiKey=j1ttIfJ4D9Aol5Ru3bFCtLTAilPI2-v1',
    
    contentType: "application/json"
}).success(function(data) {
    
    var dat=angular.fromJson(data);
    for(i=0;i<dat.length;i++)
        {
            if(angular.equals(dat[i].name,username) && angular.equals(dat[i].password,password)){
              
                
                $window.location.href="directions.html";
               $scope.msg ="User logged in successfully"; 
                alert("Hi");
                break;
            }
            else 
            {
                 $scope.msg ="User login error";
                alert("bye");
            }
                    
    }
    
    
        })
}
$scope.updateuser1 = function(new_user_name,new_password,new_emailid) {
   //alert('hie');
var id =localStorage.getItem("id_user");
      // alert(id);
    
    $http({
    method: 'PUT',
    url : 'https://api.mongolab.com/api/1/databases/ase_lab1/collections/users/'+id+'?apiKey=j1ttIfJ4D9Aol5Ru3bFCtLTAilPI2-v1',
    data: JSON.stringify({
                "name": new_user_name,
                "password": new_password,
                "email" : new_emailid
                
            }),
    contentType: "application/json"
}).success(function() {
    //alert('success');
    
        })

}

$scope.deleteuser1 = function(user_name) {
   //alert('hie');
var id =localStorage.getItem("id_user");
      // alert(id);
    
    $http({
    method: 'DELETE',
    url : 'https://api.mongolab.com/api/1/databases/ase_lab1/collections/users/'+id+'?apiKey=j1ttIfJ4D9Aol5Ru3bFCtLTAilPI2-v1',
   
}).success(function() {
    alert('success');
    
        })

}
    
});  